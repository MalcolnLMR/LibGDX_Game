Raw assets were extracted using [Skin Composer](https://github.com/raeleus/skin-composer).
